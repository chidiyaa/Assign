package com.cg.demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {
	public static void main(String args[])
	{

		ClassPathXmlApplicationContext factory=
				new ClassPathXmlApplicationContext("anno.xml");
		//Employee emp=(Employee)factory.getBean("eBean");
		Employee empl=factory.getBean(Employee.class);
		System.out.println(empl);
	}
}
